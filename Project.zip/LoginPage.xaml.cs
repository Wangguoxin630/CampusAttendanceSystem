namespace CampusAttendanceSystem;

public partial class LoginPage : ContentPage
{
    public LoginPage()
    {
        InitializeComponent();
    }

    private async void LoginClicked(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(txtStudentId.Text) && !string.IsNullOrWhiteSpace(txtPassword.Text))
        {
            await Shell.Current.GoToAsync("//CheckInPage");
        }
        else
        {
            await DisplayAlert("Notice", "Please fill in all fields", "OK");
        }
    }
}
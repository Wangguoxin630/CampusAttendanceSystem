namespace CampusAttendanceSystem;

public partial class RecordPage : ContentPage
{
    public RecordPage()
    {
        InitializeComponent();
        cvRecords.ItemsSource = CheckInPage.Records;
    }

    private async void GoBack(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//CheckInPage");
    }
}
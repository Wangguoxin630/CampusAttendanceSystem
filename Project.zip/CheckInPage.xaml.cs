namespace CampusAttendanceSystem;

public partial class CheckInPage : ContentPage
{
    public static List<string> Records = new();

    public CheckInPage()
    {
        InitializeComponent();
        ShowTime();
    }

    private void ShowTime()
    {
        lblTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
    }

    private async void CheckInClicked(object sender, EventArgs e)
    {
        ShowTime();
        var msg = $"Check In: {lblTime.Text}";
        Records.Add(msg);
        await DisplayAlert("Success", msg, "OK");
    }

    private async void CheckOutClicked(object sender, EventArgs e)
    {
        ShowTime();
        var msg = $"Check Out: {lblTime.Text}";
        Records.Add(msg);
        await DisplayAlert("Success", msg, "OK");
    }

    private async void GoToRecords(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//RecordPage");
    }
}